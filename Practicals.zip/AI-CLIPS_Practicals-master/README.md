# AI-CLIPS
Predicate logic applied in CLIPS for AI module.

Code left public, for people that might find it helpful.
